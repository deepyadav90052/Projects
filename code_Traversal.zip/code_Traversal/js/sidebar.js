const menuBtn = document.querySelector('.menu');
const sidebar = document.querySelector('.sidebar');

//Adding Event Listener to menu btn
menuBtn.addEventListener('click', () => {
	sidebar.classList.add('showSidebar');
});

//Adding Event Listener to document
document.addEventListener('mouseup', (e) => {
		if(!sidebar.contains(e.target)){
		sidebar.classList.remove('showSidebar');
	}
});