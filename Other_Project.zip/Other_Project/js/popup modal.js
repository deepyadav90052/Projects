let popup = document.querySelector('.popup');

let openModal = () => {
	popup.classList.add('popup_open');
}

let closeModal = () => {
    popup.classList.remove('popup_open');
}