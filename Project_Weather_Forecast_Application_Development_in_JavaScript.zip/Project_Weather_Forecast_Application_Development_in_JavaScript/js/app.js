const apiKey = "1284527fdebd31f5351a00a8e2659794";
const searchButton = document.getElementById("search");
const currentLocationButton = document.getElementById("current-location");
const cityInput = document.getElementById("city");
const locationDisplay = document.getElementById("location");
const tempDisplay = document.getElementById("temp");
const windDisplay = document.getElementById("wind");
const humidityDisplay = document.getElementById("humidity");
const weatherIcon = document.getElementById("weather-icon");
const forecastContainer = document.getElementById("forecast");

const getWeatherData = async (city) => {
    try {
        const response = await fetch(`https://api.openweathermap.org/data/2.5/weather?q=${city}&units=metric&appid=${apiKey}`);
        if (!response.ok) throw new Error("City not found");
        const data = await response.json();
        updateWeatherUI(data);
        getForecastData(city);
    } catch (error) {
        alert(error.message);
    }
};

const getForecastData = async (city) => {
    try {
        const response = await fetch(`https://api.openweathermap.org/data/2.5/forecast?q=${city}&units=metric&appid=${apiKey}`);
        if (!response.ok) throw new Error("Forecast data not available");
        const data = await response.json();
        updateForecastUI(data);
    } catch (error) {
        alert(error.message);
    }
};

const updateWeatherUI = (data) => {
    locationDisplay.textContent = `${data.name} (${new Date().toISOString().split('T')[0]})`;
    tempDisplay.textContent = `Temperature: ${data.main.temp}°C`;
    windDisplay.textContent = `Wind: ${data.wind.speed} M/S`;
    humidityDisplay.textContent = `Humidity: ${data.main.humidity}%`;
    weatherIcon.textContent = getWeatherIcon(data.weather[0].main);
};

const updateForecastUI = (data) => {
    forecastContainer.innerHTML = "";
    const dailyForecasts = {};
    
    data.list.forEach((forecast) => {
        const date = forecast.dt_txt.split(" ")[0];
        if (!dailyForecasts[date]) {
            dailyForecasts[date] = forecast;
        }
    });
    
    Object.keys(dailyForecasts).slice(0, 5).forEach((date) => {
        const forecast = dailyForecasts[date];
        const forecastElement = document.createElement("div");
        forecastElement.classList = "bg-gray-200 p-4 rounded-lg text-center";
        forecastElement.innerHTML = `
            <p>(${date})</p>
            <div class="text-4xl">${getWeatherIcon(forecast.weather[0].main)}</div>
            <p>Temp: ${forecast.main.temp}°C</p>
            <p>Wind: ${forecast.wind.speed} M/S</p>
            <p>Humidity: ${forecast.main.humidity}%</p>
        `;
        forecastContainer.appendChild(forecastElement);
    });
};

const getWeatherIcon = (condition) => {
    const icons = {
        Clear: "☀️",
        Clouds: "☁️",
        Rain: "🌧️",
        Snow: "❄️",
        Thunderstorm: "⛈️",
        Drizzle: "🌦️",
        Mist: "🌫️"
    };
    return icons[condition] || "❓";
};

searchButton.addEventListener("click", () => {
    const city = cityInput.value.trim();
    if (city) getWeatherData(city);
});

currentLocationButton.addEventListener("click", () => {
    if (navigator.geolocation) {
        navigator.geolocation.getCurrentPosition(async (position) => {
            const { latitude, longitude } = position.coords;
            try {
                const response = await fetch(`https://api.openweathermap.org/data/2.5/weather?lat=${latitude}&lon=${longitude}&units=metric&appid=${apiKey}`);
                if (!response.ok) throw new Error("Location weather not found");
                const data = await response.json();
                updateWeatherUI(data);
                getForecastData(data.name);
            } catch (error) {
                alert(error.message);
            }
        });
    } else {
        alert("Geolocation is not supported by your browser");
    }
});
