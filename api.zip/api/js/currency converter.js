const fromAmountElement = document.querySelector('.amount');
const convertedAmountElement = document.querySelector('.convertedAmount');
const fromCurrencyElement = document.querySelector('.fromCurrency');
const toCurrencyElement = document.querySelector('.toCurrency');
const resultElement = document.querySelector('.result');

// Array to populate the select tags with these countries
const countries = [
    { code: "USD", name: "United States Dollar" },
    { code: "INR", name: "Indian Rupee" },
];

// Showing countries from array to select tag
countries.forEach(country => {
	const option1 = document.createElement('option');
	const option2 = document.createElement('option');

	option1.value = option2.value = country.code;
	option1.textContent = option2.textContent = `${country.code} (${country.name})`;

	fromCurrencyElement.appendChild(option1);
	toCurrencyElement.appendChild(option2);
});